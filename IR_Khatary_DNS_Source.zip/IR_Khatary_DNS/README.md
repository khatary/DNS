# IR_Khatary DNS (Android)

An Android Java project with a neon-style Persian UI and a DNS-only `VpnService` prototype. The service configures the supplied IPv4 DNS resolvers and forwards IPv4/UDP DNS packets to them.

## DNS servers
- `87.248.145.40`
- `193.242.208.98`

## Build APK in GitHub
1. Upload/push this project to a GitHub repository.
2. Open **Actions** and run the workflow `Build Android APK` (or push to the `main` branch).
3. Download `IR-Khatary-DNS-debug-apk` from the workflow run's Artifacts.

## Important limitations
- This is a DNS-only VPN, not a full-tunnel VPN. It does not proxy gameplay packets and cannot promise lower PUBG ping.
- The packet handler currently handles IPv4 UDP DNS only; DNS-over-TLS/HTTPS, IPv6 DNS, TCP DNS, fragmented IP packets, and some OEM-specific resolver behavior are not supported.
- Android 4+ is the declared minimum (`minSdk 14`), but the modern Android build toolchain and emulator/device testing should be used before release. For Android 4-era devices, build compatibility and WebView behavior require validation.
- A successful APK build is not proof of network functionality. Test on Wi-Fi and mobile data, verify DNS resolution, test failover, and ensure stopping the VPN restores normal connectivity.
- No third-party analytics, ads, or account permissions are included. Android will display the system VPN consent prompt.

## Build locally
Use JDK 17 and Android SDK Platform 35, then run `gradle assembleDebug`. APK output: `app/build/outputs/apk/debug/app-debug.apk`.
